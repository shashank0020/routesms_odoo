{
    'name': 'test_convert',
    'description': "Data for xml conversion tests",
    'version': '0.0.1',
}
