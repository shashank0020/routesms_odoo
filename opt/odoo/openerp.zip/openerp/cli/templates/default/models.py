# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class {{ name|snake }}(models.Model):
#     _name = '{{ name|snake }}.{{ name|snake }}'

#     name = fields.Char()
